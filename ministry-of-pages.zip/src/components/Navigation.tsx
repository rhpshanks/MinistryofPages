import { Search, ShoppingCart, Menu, Heart } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

interface NavigationProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export default function Navigation({ searchQuery, onSearchChange }: NavigationProps) {
  const { cartCount, setIsCartOpen } = useCart();
  const { wishlistCount } = useWishlist();

  return (
    <header className="sticky top-0 z-50 w-full bg-slate-900/95 backdrop-blur supports-[backdrop-filter]:bg-slate-900/80 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center">
            <a href="#" className="flex-shrink-0 text-white font-serif text-2xl font-bold tracking-tight">
              Ministry of Pages
            </a>
            <nav className="hidden md:ml-10 md:flex md:space-x-8">
              <a href="#" className="text-white hover:text-amber-500 px-3 py-2 text-sm font-medium transition-colors">Home</a>
              <a href="#" className="text-amber-500 px-3 py-2 text-sm font-medium transition-colors">Products</a>
              <a href="#" className="text-slate-300 hover:text-amber-500 px-3 py-2 text-sm font-medium transition-colors">About</a>
              <a href="#" className="text-slate-300 hover:text-amber-500 px-3 py-2 text-sm font-medium transition-colors">Contact</a>
            </nav>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="hidden sm:flex relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                placeholder="Search precise pages..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="block w-full rounded-md border-0 bg-slate-800 py-1.5 pl-10 pr-3 text-white placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:ring-2 focus:ring-inset focus:ring-amber-500 sm:text-sm sm:leading-6 transition-all"
              />
            </div>
            
            <div className="flex items-center space-x-4">
              <button 
                className="relative text-slate-300 hover:text-white transition-colors"
                aria-label="Wishlist"
              >
                <span className="sr-only">Items in wishlist</span>
                <Heart className="h-6 w-6" />
                {wishlistCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-slate-700 text-[10px] font-bold text-white">
                    {wishlistCount > 99 ? '99+' : wishlistCount}
                  </span>
                )}
              </button>
              
              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative text-slate-300 hover:text-white transition-colors"
                aria-label="Cart"
              >
                <span className="sr-only">Items in cart</span>
                <ShoppingCart className="h-6 w-6" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-[10px] font-bold text-white">
                    {cartCount > 99 ? '99+' : cartCount}
                  </span>
                )}
              </button>
            </div>

            <button className="md:hidden text-slate-300 hover:text-white transition-colors">
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
